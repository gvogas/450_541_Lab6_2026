using UnityEngine;
using TMPro;
 
// Shows the score the player finished the level with.
public class EndScreen : MonoBehaviour
{
    [SerializeField] private TMP_Text finalScoreText;
 
    private void Start()
    {
        // No ScoreManager object exists in this scene, but we can
        // still read the static FinalScore through the class name
        finalScoreText.text = "Final Score: " + ScoreManager.FinalScore;
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;



    }
}
